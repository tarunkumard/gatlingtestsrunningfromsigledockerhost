package simulations

import baseConfig.BaseSimulation
import io.gatling.core.Predef._
import io.gatling.http.Predef._

import scala.concurrent.duration.DurationInt

class companystoreautomation extends BaseSimulation {

  val headers_190 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_302 = Map("Referer" -> "https://companystoretest.wizards.com/")

  val headers_5124 = Map(
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_5125 = Map(
    "Accept" -> "application/json, text/javascript, */*; q=0.01",
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_5126 = Map(
    "Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Cache-Control" -> "no-cache",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "Upgrade-Insecure-Requests" -> "1")
  val headers_188 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/",
    "sec-fetch-mode" -> "cors",
    "sec-fetch-site" -> "same-origin",
    "x-requested-with" -> "XMLHttpRequest")
  val headers_007 = Map(
    "Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Cache-Control" -> "no-cache",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/",
    "TE" -> "Trailers",
    "Upgrade-Insecure-Requests" -> "1")


  val headers_60007 = Map(
    "Accept" -> "application/json, text/javascript, */*; q=0.01",
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_61007 = Map(
    "Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Cache-Control" -> "no-cache",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "Upgrade-Insecure-Requests" -> "1")

  val headers_189 = Map(
    "accept" -> "application/json, text/javascript, */*; q=0.01",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/",
    "sec-fetch-mode" -> "cors",
    "sec-fetch-site" -> "same-origin",
    "x-requested-with" -> "XMLHttpRequest")

  val headers_288 = Map(
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_289 = Map(
    "Accept" -> "application/json, text/javascript, */*; q=0.01",
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")



  val headers_249 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "none",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_59007 = Map(
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")



  val headers_224 = Map(
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_125 = Map(
    "Accept" -> "application/json, text/javascript, */*; q=0.01",
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_126 = Map(
    "Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Cache-Control" -> "no-cache",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "Upgrade-Insecure-Requests" -> "1")

  val headers_322 = Map(
    "Referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-deluxe-collection/",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_367 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "multipart/form-data; boundary=----WebKitFormBoundaryLC3qIGHCuMBtXAB3",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-deluxe-collection/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")



  val headers_432 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "multipart/form-data; boundary=----WebKitFormBoundaryv7dTjEFBVdiyBBtc",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-deluxe-collection/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_496 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-deluxe-collection/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_2123 = Map(
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_2124 = Map(
    "Accept" -> "application/json, text/javascript, */*; q=0.01",
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_2125 = Map(
    "Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Cache-Control" -> "no-cache",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "Upgrade-Insecure-Requests" -> "1")

  val headers_0 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_1 = Map(
    "accept" -> "text/css,*/*;q=0.1",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/my-account/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_10 = Map(
    "Referer" -> "https://companystoretest.wizards.com/my-account/",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_14 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/my-account/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_51 = Map(
    "Origin" -> "https://companystoretest.wizards.com",
    "Referer" -> "https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&subset=latin,latin-ext",
    "Sec-Fetch-Mode" -> "cors")

  val headers_56 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/my-account/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_57 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/my-account/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_111 = Map(
    "accept" -> "text/css,*/*;q=0.1",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_122 = Map(
    "Referer" -> "https://companystoretest.wizards.com/",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_124 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_163 = Map("Referer" -> "https://companystoretest.wizards.com/")

  val headers_165 = Map(
    "accept" -> "text/css,*/*;q=0.1",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_178 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_185 = Map(
    "Referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_228 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_283 = Map(
    "accept" -> "text/css,*/*;q=0.1",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-deluxe-collection/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_297 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-deluxe-collection/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_305 = Map(
    "Referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-deluxe-collection/",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_346 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "multipart/form-data; boundary=----WebKitFormBoundaryTTTgZwj1FSwpAEmZ",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-deluxe-collection/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_409 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-deluxe-collection/",
    "sec-fetch-mode" -> "cors",
    "sec-fetch-site" -> "same-origin",
    "x-requested-with" -> "XMLHttpRequest")

  val headers_411 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-deluxe-collection/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_412 = Map(
    "accept" -> "text/css,*/*;q=0.1",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_422 = Map(
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_424 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_469 = Map(
    "accept" -> "image/webp,image/apng,image/*,*/*;q=0.8",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=3.6.5",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_470 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/",
    "sec-fetch-mode" -> "cors",
    "sec-fetch-site" -> "same-origin",
    "x-requested-with" -> "XMLHttpRequest")

  val headers_471 = Map(
    "accept" -> "application/json, text/javascript, */*; q=0.01",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/",
    "sec-fetch-mode" -> "cors",
    "sec-fetch-site" -> "same-origin",
    "x-requested-with" -> "XMLHttpRequest")

  val headers_472 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_473 = Map(
    "accept" -> "text/css,*/*;q=0.1",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114407/?key=wc_order_p2BRPUKUm4sCc",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_483 = Map(
    "Referer" -> "https://companystoretest.wizards.com/checkout/order-received/114407/?key=wc_order_p2BRPUKUm4sCc",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_486 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114407/?key=wc_order_p2BRPUKUm4sCc",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_530 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114407/?key=wc_order_p2BRPUKUm4sCc",
    "sec-fetch-mode" -> "cors",
    "sec-fetch-site" -> "same-origin",
    "x-requested-with" -> "XMLHttpRequest")

  val headers_532 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114407/?key=wc_order_p2BRPUKUm4sCc",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_697 = Map(
    "accept" -> "text/css,*/*;q=0.1",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/my-account/orders/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_708 = Map(
    "Referer" -> "https://companystoretest.wizards.com/my-account/orders/",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_710 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/my-account/orders/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_749 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/my-account/orders/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_804 = Map(
    "accept" -> "text/css,*/*;q=0.1",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-mobi-version/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_816 = Map(
    "Referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-mobi-version/",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_819 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-mobi-version/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_867 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "multipart/form-data; boundary=----WebKitFormBoundaryGe2yTbjZPT3PVFnZ",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-mobi-version/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_931 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-mobi-version/",
    "sec-fetch-mode" -> "cors",
    "sec-fetch-site" -> "same-origin",
    "x-requested-with" -> "XMLHttpRequest")

  val headers_932 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-mobi-version/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_994 = Map(
    "accept" -> "text/css,*/*;q=0.1",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114409/?key=wc_order_Rqo7xwPed3M0v",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_1006 = Map(
    "Referer" -> "https://companystoretest.wizards.com/checkout/order-received/114409/?key=wc_order_Rqo7xwPed3M0v",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_1007 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114409/?key=wc_order_Rqo7xwPed3M0v",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_1051 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114409/?key=wc_order_Rqo7xwPed3M0v",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_1104 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/my-account/",
    "sec-fetch-mode" -> "cors",
    "sec-fetch-site" -> "same-origin",
    "x-requested-with" -> "XMLHttpRequest")

  val headers_1335 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "multipart/form-data; boundary=----WebKitFormBoundaryOnpFSNlDJNltUDrq",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_1399 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/",
    "sec-fetch-mode" -> "cors",
    "sec-fetch-site" -> "same-origin",
    "x-requested-with" -> "XMLHttpRequest")

  val headers_1462 = Map(
    "accept" -> "text/css,*/*;q=0.1",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114411/?key=wc_order_aaLJASQdJn8Dh",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_1471 = Map(
    "Referer" -> "https://companystoretest.wizards.com/checkout/order-received/114411/?key=wc_order_aaLJASQdJn8Dh",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_1474 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114411/?key=wc_order_aaLJASQdJn8Dh",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_1519 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114411/?key=wc_order_aaLJASQdJn8Dh",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_1792 = Map(
    "accept" -> "text/css,*/*;q=0.1",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/my-account/view-order/43177/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_1803 = Map(
    "Referer" -> "https://companystoretest.wizards.com/my-account/view-order/43177/",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_1805 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/my-account/view-order/43177/",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_1844 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/my-account/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "upgrade-insecure-requests" -> "1")

  val headers_2015 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "multipart/form-data; boundary=----WebKitFormBoundary8tHuPuQl7itDByio",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_2142 = Map(
    "accept" -> "text/css,*/*;q=0.1",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114413/?key=wc_order_myQbmtLz5D7PQ",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_2154 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114413/?key=wc_order_myQbmtLz5D7PQ",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_2158 = Map(
    "Referer" -> "https://companystoretest.wizards.com/checkout/order-received/114413/?key=wc_order_myQbmtLz5D7PQ",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_2199 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114413/?key=wc_order_myQbmtLz5D7PQ",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_2536 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "multipart/form-data; boundary=----WebKitFormBoundaryZckR2RbDB3iWSElV",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_2663 = Map(
    "accept" -> "text/css,*/*;q=0.1",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114415/?key=wc_order_dT5Kw7bgVMc1b",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_2674 = Map(
    "accept" -> "*/*",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/order-received/114415/?key=wc_order_dT5Kw7bgVMc1b",
    "sec-fetch-mode" -> "no-cors",
    "sec-fetch-site" -> "same-origin")

  val headers_2681 = Map(
    "Referer" -> "https://companystoretest.wizards.com/checkout/order-received/114415/?key=wc_order_dT5Kw7bgVMc1b",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_011 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_112 = Map(
    "Referer" -> "https://companystoretest.wizards.com/",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_48 = Map(
    "Origin" -> "https://companystoretest.wizards.com",
    "Referer" -> "https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&subset=latin,latin-ext",
    "Sec-Fetch-Mode" -> "cors")

  val headers_5321 = Map("Referer" -> "https://companystoretest.wizards.com/")

  val headers_551 = Map(
    "Referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_1181 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "content-type" -> "multipart/form-data; boundary=----WebKitFormBoundaryrmji1thTwVBXDjx4",
    "origin" -> "https://companystoretest.wizards.com",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_1821 = Map(
    "Accept" -> "*/*",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/",
    "Sec-Fetch-Mode" -> "cors",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_1831 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_1851 = Map(
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_2412 = Map(
    "Referer" -> "https://companystoretest.wizards.com/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=3.6.5",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_2421 = Map(
    "Accept" -> "*/*",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "Sec-Fetch-Mode" -> "cors",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_2431 = Map(
    "Accept" -> "application/json, text/javascript, */*; q=0.01",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "Sec-Fetch-Mode" -> "cors",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_2441 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "cache-control" -> "no-cache",
    "pragma" -> "no-cache",
    "referer" -> "https://companystoretest.wizards.com/checkout/",
    "sec-fetch-mode" -> "navigate",
    "sec-fetch-site" -> "same-origin",
    "sec-fetch-user" -> "?1",
    "upgrade-insecure-requests" -> "1")

  val headers_24512 = Map(
    "Referer" -> "https://companystoretest.wizards.com/checkout/order-received/114606/?key=wc_order_UaeIAA09oNe59",
    "Sec-Fetch-Mode" -> "no-cors")

  val headers_59 = Map(
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_60 = Map(
    "Accept" -> "application/json, text/javascript, */*; q=0.01",
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_61 = Map(
    "Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Cache-Control" -> "no-cache",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "Upgrade-Insecure-Requests" -> "1")

  val headers_324 = Map(
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_325 = Map(
    "Accept" -> "application/json, text/javascript, */*; q=0.01",
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_336 = Map(
    "Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Cache-Control" -> "no-cache",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "Upgrade-Insecure-Requests" -> "1")

  val headers_020 = Map(
    "Accept" -> "application/json, text/javascript, */*; q=0.01",
    "Cache-Control" -> "no-cache",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://companystoretest.wizards.com",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_1020 = Map(
    "Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Cache-Control" -> "no-cache",
    "Pragma" -> "no-cache",
    "Referer" -> "https://companystoretest.wizards.com/checkout/",
    "TE" -> "Trailers",
    "Upgrade-Insecure-Requests" -> "1")


  val uri1 = "https://s.w.org/images/core/emoji/12.0.0-1/svg/1f50d.svg"
  val uri2 = "https://s3-us-west-2.amazonaws.com/companystore-uploads/wp-content/uploads/2016/03/wotc-costo_j.png"
  val uri4 = "https://login.microsoftonline.com/701edd3e-c7a8-4789-b1ce-8a243620d68f/saml2"
  val uri5 = "https://fonts.gstatic.com/s/opensans/v17"
  val uri6 = "https://fonts.googleapis.com/css"

  val chain_0 = exec(http("UserOrder1")
    .get("/my-account/")
    .headers(headers_0))
    .pause(39)
    .exec(http("Userorder56")
      .post("/my-account/")
      .headers(headers_56)
      .formParam("username", "ansellw  ")
      .formParam("password", "2zuyrU3PHAA@%J2UXHUvg3cQ")
      .formParam("woocommerce-login-nonce", "1727039b37")
      .formParam("_wp_http_referer", "/my-account/")
      .formParam("login", "Log in")
      .check(status.in(200,302)))
    .exec(http("Userorder57")
      .get("/my-account/")
      .headers(headers_57))
  exec(http("Userorder298")
    .post("/?wc-ajax=update_order_review")
    .headers(headers_288)
    .formParam("security", "43063111b5")
    .formParam("country", "US")
    .formParam("address", "WOTC")
    .formParam("s_country", "US")
    .formParam("s_address", "WOTC")
    .formParam("has_full_address", "true")
    .formParam("post_data", "billing_first_name=Ryan&billing_last_name=Acierto&billing_country=US&billing_address_1=WOTC&billing_email=Ryan.Acierto%40wizards.com&order_comments=&woocommerce-process-checkout-nonce=d665ae0fe4&_wp_http_referer=%2Fcheckout%2F"))
    .pause(11)
    .exec(http("Userorder289")
      .post("/?wc-ajax=checkout")
      .headers(headers_189)
      .formParam("billing_first_name", "Ryan")
      .formParam("billing_last_name", "Acierto")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "WOTC")
      .formParam("billing_email", "Ryan.Acierto@testingwizards.com")
      .formParam("order_comments", "for testing")
      .formParam("woocommerce-process-checkout-nonce", "d665ae0fe4")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))


  val chain_1 = exec(http("Userorder99")

    .get(uri4 + "?SAMLRequest=jZJRb9sgFIXf9yss3rENcRwH1amyRtUidVvUpHvYy0TwdYqELx7gZu2vH3EWqZPWarxxOFd85957df2rM8kTOK8t1oSlOUkAlW00HmrysLulFbleXHnZmV4sh%2FCI9%2FBzAB%2BSWIdejA81GRwKK732AmUHXgQltsvPd4KnueidDVZZQ84l75ul9%2BBCZCHJelWTH%2FspzFnJpyUrJlAqVXG253zCimI6m%2BwL1pRFM%2BNtO%2Bck%2BXZJwU8p1t4PsEYfJIYo5WxOWU55seNM5HPBqu8k2fxB%2B6jxHPg9tP3Z5MWn3W5DN1%2B3O5IsL7g3Fv3QgduCe9IKHu7vavIYQu9Flinb9RKffbAO0qN%2Bka7xaRQzkqxiJzXKMGJf%2FMYeNKadVs562waLRiOMBbOcQdNMgKqZrGgxq%2BZ0zxTQSvJiUvK8Kas2O42Ek%2FPMxNgF92pY%2F9v%2Bxb%2FpbVA0Kp1FGufapEHLTgZqnT4xK2OHJjv20YIBMGS9GaLus06jtk7iAegJgvKc%2BthLE6%2F6gNRidpW94r0s3JcIuF5trNHqOVkaY483DmSAmgQ3AElurYu%2Fvx2JpWxUdEPb0SoG9D0o3WpoyIfkjZMtzjR%2Fb%2FziNw%3D%3D&RelayState=%2Fwp-content%2Fuploads%2F2019%2F08%2Fserra1.jpg&SigAlg=http%3A%2F%2Fwww.w3.org%2F2001%2F04%2Fxmldsig-more%23rsa-sha256&Signature=AKliHRWboXYFxXaqYpGJrp2DwFKXQ%2FnDbCSEZrC0BNLEIfy0lXExIMf78L2RCeSmeuCMU%2B9pRIlwxsmQwTzV0b5vyRyKfd%2BVH06qpHib068kWyCX36cEH8C0%2BNL3iwyqxmWFwoY5UoE%2B1K5Y5E9zD%2F1jTgreX9lOTe6RyUDygU%2FIEQONgCsvKUIjiXxOT5JAmVk0zLyVzshHaPWc2DlFCMIi9WsNaosUCtKuLBB%2BSKTtQhFnbLLLQf%2FPq4c%2BbZWZ%2B0GwArpWVEDeG6ycCepqecUEQ5Xa3Aow2VEeedptk0UAI95Rv5qtTVDahBMGQPVmi39kbosb9rAMaSwIQ5cyGw%3D%3D")
    .headers(headers_163))
    .pause(3)
    .exec(http("Userorder164")
      .get("/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/")
      .headers(headers_0))
     .exec(http("Userorder0")
    .post("/?wc-ajax=update_order_review")
    .headers(headers_59)
    .formParam("security", "5d1faa6e4f")
    .formParam("country", "US")
    .formParam("address", "WOTC Renton: 440E")
    .formParam("s_country", "US")
    .formParam("s_address", "WOTC Renton: 440E")
    .formParam("has_full_address", "true")
    .formParam("post_data", "billing_first_name=Ben&billing_last_name=Abbey&billing_country=US&billing_address_1=WOTC+Renton%3A+440E&billing_email=Ben.Abbey%40wizards.com&order_comments=&woocommerce-process-checkout-nonce=081a30405c&_wp_http_referer=%2Fcheckout%2F"))
    .pause(15)
    .exec(http("Userorder60")
      .post("/?wc-ajax=checkout")
      .headers(headers_60)
      .formParam("billing_first_name", "Ben")
      .formParam("billing_last_name", "Abbey")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "WOTC Renton: 440E")
      .formParam("billing_email", "Ben.Abbey@testingwizards.com")
      .formParam("order_comments", "Only For Perf Tests")
      .formParam("woocommerce-process-checkout-nonce", "081a30405c")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .exec(http("Userorder61")
      .get("/checkout/order-received/114670/?key=wc_order_aytRWUskzFKIM")
      .headers(headers_61))


  val chain_2 = exec(http("Userorder196")


    .get(uri4 + "?SAMLRequest=jZLNbtswEITvfQqBd0qipOqHsBy4MYIaSFsjdnropaDJlUNAWqoklTR9%2BtJyDaRAE5Q3DmfBb3Z3cfVz6KNHsE4bbAmLUxIBSqM0Hltyv7%2BhNblaLpwY%2BpGvJv%2BAd%2FBjAuejUIeOzw8tmSxyI5x2HMUAjnvJd6tPtzyLUz5a4400PTmXvG0WzoH1gYVEm3VLvjeyKJqqzjPxvmG56uqySnMJVVk3ZXcQcGBMNEoVXU6ir5cU2SnFxrkJNui8QB%2BklDWUpTQr9hnjacOL8huJtn%2FQPmg8B34L7XA2Of5xv9%2FS7ZfdnkSrC%2B61QTcNYHdgH7WE%2B7vbljx4PzqeJNIMo8Bn542F%2BEn%2FEla5OIgJidahkxqFn7Ev%2Ft4cNcaDltY403mDvUaYC6qUgVI5UFmJmhZV3dADk0BrkRV5maWqrLvkNJKMnGfG5y7YF8P63%2FYv%2F01vvKRBGQzSMFcVey0G4amx%2BsQsezOp5GkMFvSAPhn7KeguGTRqYwUegZ4gaJZSF3rZh6s%2BIjWYLJIXvJeF%2BxwAN%2But6bV8jlZ9b56uLQgPLfF2AhLdGBt%2Bfz0Si9msaEW72condCNI3WlQ5F30ykmWZ5q%2FN375Gw%3D%3D&RelayState=%2Fwp-content%2Fuploads%2F2019%2F08%2Fserra1.jpg&SigAlg=http%3A%2F%2Fwww.w3.org%2F2001%2F04%2Fxmldsig-more%23rsa-sha256&Signature=VwzplhCeNKXBVAY3DAMdSsnNHT6g8QgEBrDICZJVZG17Px%2BgGWwJ4I48H3K%2BigfyOH9e0ECnwkicxDenRSh29lbx1P2%2B%2FsRShfDPUcOXEiJRiswKDg05w%2FrW1OykCG4fBkozTugPJYFG1Vo8LwH6X9Etod7pGhNOUu0%2Fjw1nDu7cWVS430w1BCPSKb9upvibD0TbZDQ95PYEsHNtkMajBCadg4CxXvf77lWxmUYLB6Efjq9XEtcoND4PZcgvtEUvXwgHq4EHRvcHqztuWYCW4Whh3%2FrQZmzebWZkolWq7ycgdSGApj2nQYt3sl0muRE%2FcFkWrbaGLhBi3tjW1eu1tw%3D%3D")
    .headers(headers_163))
    .pause(3)
    .exec(http("Userorder282")
      .get("/product/mtg-throne-of-eldraine-deluxe-collection/")
      .headers(headers_0))
  exec(http("Userorder0")
    .post("/?wc-ajax=update_order_review")
    .headers(headers_324)
    .formParam("security", "592b066278")
    .formParam("country", "US")
    .formParam("address", "370M")
    .formParam("s_country", "US")
    .formParam("s_address", "370M")
    .formParam("has_full_address", "true")
    .formParam("post_data", "billing_first_name=Sydney&billing_last_name=Adams&billing_country=US&billing_address_1=370M&billing_email=Sydney.Adams%40wizards.com&order_comments=&woocommerce-process-checkout-nonce=a893474d95&_wp_http_referer=%2Fcheckout%2F"))
    .pause(9)
    .exec(http("Userorder325")
      .post("/?wc-ajax=checkout")
      .headers(headers_325)
      .formParam("billing_first_name", "Sydney")
      .formParam("billing_last_name", "Adams")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "370M")
      .formParam("billing_email", "Sydney.Adams@testingwizards.com")
      .formParam("order_comments", "Just for perf testing")
      .formParam("woocommerce-process-checkout-nonce", "a893474d95")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .exec(http("Userorder126")
      .get("/checkout/order-received/114681/?key=wc_order_ZsWDGsVK06MsX")
      .headers(headers_336))
    .exec(http("Userorder5124")
      .post("/?wc-ajax=update_order_review")
      .headers(headers_5124)
      .formParam("security", "cdd525693e")
      .formParam("country", "US")
      .formParam("address", "Dominaria")
      .formParam("s_country", "US")
      .formParam("s_address", "Dominaria")
      .formParam("has_full_address", "true")
      .formParam("post_data", "billing_first_name=Mary+Kathryn&billing_last_name=Amiotte&billing_country=US&billing_address_1=Dominaria&billing_email=MaryKathryn.Amiotte%40wizards.com&order_comments=&woocommerce-process-checkout-nonce=14caf551ed&_wp_http_referer=%2Fcheckout%2F"))
    .pause(9)
    .exec(http("Userorder5125")
      .post("/?wc-ajax=checkout")
      .headers(headers_5125)
      .formParam("billing_first_name", "Mary Kathryn")
      .formParam("billing_last_name", "Amiotte")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "Dominaria")
      .formParam("billing_email", "MaryKathryn.Amiotte@testingwizards.com")
      .formParam("order_comments", "for perf testing")
      .formParam("woocommerce-process-checkout-nonce", "14caf551ed")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .exec(http("Userorder5126")
      .get("/checkout/order-received/114732/?key=wc_order_rrsTwmqVVIkVt")
      .headers(headers_5126))

  val chain_3 = exec(http("Userorder292")
    .post("/product/mtg-throne-of-eldraine-deluxe-collection/")
    .headers(headers_346)
    .body(RawFileBody("companystoretestNoMfa24Oct2019_0346_request.txt")))
    .exec(http("Userorder99")
      .post("/?wc-ajax=update_order_review")
      .headers(headers_224)
      .formParam("security", "5ca1cb1ae4")
      .formParam("country", "US")
      .formParam("address", "WOTC")
      .formParam("s_country", "US")
      .formParam("s_address", "WOTC")
      .formParam("has_full_address", "true")
      .formParam("post_data", "billing_first_name=Andy&billing_last_name=Abramovici&billing_country=US&billing_address_1=WOTC&billing_email=andy.abramovici%40wizards.com&order_comments=&woocommerce-process-checkout-nonce=f920861aa3&_wp_http_referer=%2Fcheckout%2F"))
    .pause(20)
    .exec(http("Userorder125")
      .post("/?wc-ajax=checkout")
      .headers(headers_125)
      .formParam("billing_first_name", "Andy")
      .formParam("billing_last_name", "Abramovici")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "WOTC")
      .formParam("billing_email", "andy.abramovici@testingwizards.com")
      .formParam("order_comments", "Only for perf testing")
      .formParam("woocommerce-process-checkout-nonce", "f920861aa3")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .pause(297 milliseconds)
    .exec(http("Userorder126")
      .get("/checkout/order-received/114673/?key=wc_order_eWXS8bXzDv974")
      .headers(headers_126))


  val chain_4 = exec(http("Userorder390")



    .get("/checkout/")
    .headers(headers_411))

    .exec(http("Userorder470")
      .post("/?wc-ajax=update_order_review")
      .headers(headers_470)
      .formParam("security", "15f9fb87a1")
      .formParam("payment_method", "reward_gateway")
      .formParam("country", "US")
      .formParam("address", "WOTC")
      .formParam("s_country", "US")
      .formParam("s_address", "WOTC")
      .formParam("has_full_address", "true")
      .formParam("post_data", "billing_first_name=Will&billing_last_name=Ansell&billing_country=US&billing_address_1=WOTC&billing_email=william.ansell%40wizards.com&order_comments=&payment_method=reward_gateway&woocommerce-process-checkout-nonce=4d840020fe&_wp_http_referer=%2Fcheckout%2F"))
    .pause(15)
    .exec(http("Userorder471")
      .post("/?wc-ajax=checkout")
      .headers(headers_471)
      .formParam("billing_first_name", "Will")
      .formParam("billing_last_name", "Ansell")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "WOTC")
      .formParam("billing_email", "william.ansell@testingwizards.com")
      .formParam("order_comments", "NO NEED TO FULFILL")
      .formParam("payment_method", "reward_gateway")
      .formParam("woocommerce-process-checkout-nonce", "4d840020fe")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .exec(http("Userorder472")
      .get("/checkout/order-received/114407/?key=wc_order_p2BRPUKUm4sCc")
      .headers(headers_472))
    .exec(http("Userorder0")
      .post("/?wc-ajax=checkout")
      .headers(headers_020)
      .formParam("billing_first_name", "Edwin")
      .formParam("billing_last_name", "Aguilar")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "TEXAS WHSE WOTC")
      .formParam("billing_email", "edwin.aguilar@testingwizards.com")
      .formParam("order_comments", "test perf only")
      .formParam("woocommerce-process-checkout-nonce", "4634b0b73b")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .exec(http("Userorder1")
      .get("/checkout/order-received/114720/?key=wc_order_GM2YyZhPPPDCw")
      .headers(headers_1020))
  .exec(http("Userorder0")
    .get("/checkout/")
    .headers(headers_007))

    .exec(http("Userorder59")
      .post("/?wc-ajax=update_order_review")
      .headers(headers_59007)
      .formParam("security", "53e4968e72")
      .formParam("payment_method", "reward_gateway")
      .formParam("country", "US")
      .formParam("address", "WOTC")
      .formParam("s_country", "US")
      .formParam("s_address", "WOTC")
      .formParam("has_full_address", "true")
      .formParam("post_data", "billing_first_name=Nate&billing_last_name=Alexander&billing_country=US&billing_address_1=WOTC&billing_email=Nate.Alexander%40wizards.com&order_comments=&payment_method=reward_gateway&woocommerce-process-checkout-nonce=bf2b741a90&_wp_http_referer=%2Fcheckout%2F"))
    .pause(22)
    .exec(http("Userorder60")
      .post("/?wc-ajax=checkout")
      .headers(headers_60007)
      .formParam("billing_first_name", "Nate")
      .formParam("billing_last_name", "Alexander")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "WOTC")
      .formParam("billing_email", "Nate.Alexander@testingwizards.com")
      .formParam("order_comments", "only for tests")
      .formParam("payment_method", "reward_gateway")
      .formParam("woocommerce-process-checkout-nonce", "bf2b741a90")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .pause(103 milliseconds)
    .exec(http("Userorder61")
      .get("/checkout/order-received/114725/?key=wc_order_sphwiGnkbGYzH")
      .headers(headers_61007))






  val chain_6 = pause(2)

    .exec(http("Userorder642")
      .post("/my-account/")
      .headers(headers_56)
      .formParam("username", "armatot  ")
      .formParam("password", "m^9XmizZ54wbG4D!!5xwHnGM")
      .formParam("woocommerce-login-nonce", "1727039b37")
      .formParam("_wp_http_referer", "/my-account/")
      .formParam("login", "Log in")
      .check(status.in(200,302)))
    .exec(http("Userorder643")
      .get("/my-account/")
      .headers(headers_57))
    .exec(http("Userorder2123")
      .post("/?wc-ajax=update_order_review")
      .headers(headers_2123)
      .formParam("security", "7bc6bff7aa")
      .formParam("country", "US")
      .formParam("address", "WOTC Renton: 232")
      .formParam("s_country", "US")
      .formParam("s_address", "WOTC Renton: 232")
      .formParam("has_full_address", "true")
      .formParam("post_data", "billing_first_name=Romeo&billing_last_name=Alvarez&billing_country=US&billing_address_1=WOTC+Renton%3A+232&billing_email=romeo.alvarez%40wizards.com&order_comments=&woocommerce-process-checkout-nonce=b004449502&_wp_http_referer=%2Fcheckout%2F"))
    .pause(9)
    .exec(http("Userorder2124")
      .post("/?wc-ajax=checkout")
      .headers(headers_2124)
      .formParam("billing_first_name", "Romeo")
      .formParam("billing_last_name", "Alvarez")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "WOTC Renton: 232")
      .formParam("billing_email", "romeo.alvarez@testingwizards.com")
      .formParam("order_comments", "testing")
      .formParam("woocommerce-process-checkout-nonce", "b004449502")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .pause(103 milliseconds)
    .exec(http("Userorder2125")
      .get("/checkout/order-received/114727/?key=wc_order_t9fQHGxZ1heEO")
      .headers(headers_2125))



  val chain_7 = exec(http("Userorder682")

    .get("/my-account/orders/")
    .headers(headers_57))

    .exec(http("Userorder749")
      .get("/")
      .headers(headers_749))


  val chain_8 = exec(http("Userorder780")

    .get(uri4 + "?SAMLRequest=jZJPbxshEMXv%2FRSIO7uA%2F62R15ETK6qltLVip4deIsyOHaTdYQts3OTTF69rKZWaqNx4vBG%2FeTOzq19NTZ7BB%2BuwpCLjlAAaV1k8lPRhe8sKejWfBd3UrVp08Qnv4WcHIZJUh0H1DyXtPCqngw0KdQNBRaM2iy93SmZctd5FZ1xNzyUfm3UI4GNioWS1LOnjVEz5eDASOz2ayiGvYL8bC2FGEzMpppoPCzBjORokjZLvly7kqYtVCB2sMESNMUlcTJngTA63Uigh1YD%2FoGT9B%2B3a4rnhj9B2Z1NQn7fbNVt%2F22wpWVxwbxyGrgG%2FAf9sDTzc35X0KcY2qDw3rmk1voToPGRH%2B6p9FbIk5pQsU5IWdeyxL%2F7aHSxmjTXeBbePDmuL0BdMuICqGgAzE12wYYqA7YQBVmg5HIwlr8bFPj%2BNRNLzzFSfgn8zrP%2BNf%2F5vehcNS0rjkKW5Vlm0utGROW9PzKZ2XZUf22TBCBjztu6SHvLGonVe4wHYCYJJzkLKsk5Xe0DmMJ%2Flb3gvC%2Fc1Aa6Wa1db80IWde2ONx50hJJG3wElt86n399vSWSiV2zF9r1VdRhaMHZvoaKfyDsnn59p%2Ft74%2BW8%3D&RelayState=%2Fwp-content%2Fuploads%2F2019%2F08%2Fserra1.jpg&SigAlg=http%3A%2F%2Fwww.w3.org%2F2001%2F04%2Fxmldsig-more%23rsa-sha256&Signature=k%2BPwAlcPUIVmQmKClRlrphsYsKvOE0Qgy38TTtKubtI0opWVkv6Dw4eZv2VvHwmsClOdtkWMheM4srQu6f8UhEXIwXemaG%2Bg%2BUpaGSrOZOzNe72TdnSjxrWrruEs50RMTc4iba4zaLx1DYuRQYmbQ2Q8BgbPZ2Xohaq6K%2FHverT9gfX5R4O60Mz3T2DDlXW89MtjJ3dMLY1gThy7P9deP58QutIp5kStnnW6wJ2SWXkbf7pbzeCeFczpIFGZ7XoFzNIDfzU3lpo8tB1YiCKp7YbW2DkOFFe1bNDpwId5pgFVK9UlFuqkHnURhy42AMM%2Frn2Q8OYzHoxkCIVkofp%2FeA%3D%3D")
    .headers(headers_163))
    .pause(7)
    .exec(http("Userorder803")
      .get("/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-mobi-version/")
      .headers(headers_0))


  val chain_9 = exec(http("Userorder876")


    .get("/checkout/")
    .headers(headers_932))



  val chain_10 = exec(http("Userorder974")


    .post("/?wc-ajax=update_order_review")
    .headers(headers_470)
    .formParam("security", "e3ca7e715a")
    .formParam("country", "US")
    .formParam("address", "WOTC-475G")
    .formParam("s_country", "US")
    .formParam("s_address", "WOTC-475G")
    .formParam("has_full_address", "true")
    .formParam("post_data", "billing_first_name=Talia&billing_last_name=Armato-Helle&billing_country=US&billing_address_1=WOTC-475G&billing_email=talia.armato-helle%40wizards.com&order_comments=&woocommerce-process-checkout-nonce=add53dbc4f&_wp_http_referer=%2Fcheckout%2F"))
    .pause(8)
    .exec(http("Userorder992")
      .post("/?wc-ajax=checkout")
      .headers(headers_471)
      .formParam("billing_first_name", "Talia")
      .formParam("billing_last_name", "Armato-Helle")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "WOTC-475G")
      .formParam("billing_email", "talia.armato-helle@testingwizards.com")
      .formParam("order_comments", "no need to fulfill")
      .formParam("woocommerce-process-checkout-nonce", "add53dbc4f")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .exec(http("Userorder993")
      .get("/checkout/order-received/114409/?key=wc_order_Rqo7xwPed3M0v")
      .headers(headers_472))

    .exec(http("Userorder1051")
      .get("/my-account/")
      .headers(headers_1051))


  val chain_11 = exec(http("Userorder1071")

    .post("/my-account/")
    .headers(headers_56)
    .formParam("username", "adamss1")
    .formParam("password", "3i7clkuZlKyE@bUAUDdS1PW*")
    .formParam("woocommerce-login-nonce", "1727039b37")
    .formParam("_wp_http_referer", "/my-account/")
    .formParam("login", "Log in")
    .check(status.in(200,302)))




  val chain_13 = exec(http("Userorder1267")

    .get(uri4 + "?SAMLRequest=jZJPbxshEMXv%2FRSIO%2FvPa3uNvI7cWFEtpa0VOz30UhGYdZDYYQts3OTTF%2B%2FWUio1UbnxeCN%2Bb2aWV79aQ57AeW2xpnmSUQIordJ4rOn94YZV9Gq19KI1HV%2F34RHv4GcPPpBYh54PDzXtHXIrvPYcRQueB8n368%2B3vEgy3jkbrLSGjiXvm4X34EJkoWS7qemPeTkBqXJRQpGrTFaiWczFosxkMZOilE3Up6JqFEwp%2BXZJUZxTbL3vYYs%2BCAxRyvIFyzNWlIci5%2FmEl9PvlOz%2BoH3UOAZ%2BD%2B1hNHn%2B6XDYsd3X%2FYGS9QX32qLvW3B7cE9awv3dbU0fQ%2Bg8T1Np207gsw%2FWQXLSL8Ipn0QxpWQTO6lRhAH74jf2qDFptXTW2yZYNBphKJhnOSg1ASbnomLlvFqwh1wCq0RRTmZFpmZVk55HUtBxZnzogns1rP9t%2F%2Brf9DZIFpXWIotzVUnQohWBWafPzNLYXqWnLlowAIa0M33Ufdpq1NYJPAI7Q7AiYz720sSrPiKzmC7TV7yXhfsSAbebnTVaPpO1MfZ07UAEqGlwPVByY138%2Fe1IeZIPilasGay8R9%2BB1I0GRT%2BQN066Gmn%2B3vjVbw%3D%3D&RelayState=%2Fwp-content%2Fuploads%2F2019%2F08%2Fserra1.jpg&SigAlg=http%3A%2F%2Fwww.w3.org%2F2001%2F04%2Fxmldsig-more%23rsa-sha256&Signature=Q1%2FI9r2Obj%2BUbjUVWSq8yZ0jWmkgCpSTj7TKofLeqYCzOshI3GPh0pNLshB4h0JZo3H9zzB4pKG1THglSmIkOcldICIwR96Rn0g8bVKYyE26PmMDeJqmzEK1F%2F4%2FAn9c%2BM%2FDDRjOFmquToZ5b9zHBPgXIN1xGK9fNHmEfaSqpssSwadBqfrMlU9uu%2FjoE4r1ivJS9cJkp63PcWoL%2BMLVivXAPRGeEqFN2x1Ax6%2FhZoREyNzU0hxZMuasESmbgvZZ0sRhNITA7bfAncEzGhjQPFagp03k5qsPqgcTHmSCbm6wJ3QahpPAJK1yIYtowk%2FddlHRu7Hse%2BK%2BYVAZ5BdkdQ%3D%3D")
    .headers(headers_163))


  val chain_14 = exec(http("Userorder1363")


      .get("/checkout/")
      .headers(headers_228))

    .exec(http("Userorder1459")
      .post("/?wc-ajax=update_order_review")
      .headers(headers_470)
      .formParam("security", "5087f68dd7")
      .formParam("country", "US")
      .formParam("address", "370M")
      .formParam("s_country", "US")
      .formParam("s_address", "370M")
      .formParam("has_full_address", "true")
      .formParam("post_data", "billing_first_name=Sydney&billing_last_name=Adams&billing_country=US&billing_address_1=370M&billing_email=Sydney.Adams%40wizards.com&order_comments=&woocommerce-process-checkout-nonce=8ed26c0094&_wp_http_referer=%2Fcheckout%2F"))

  val chain_15 = pause(8)
    .exec(http("Userorder1460")
      .post("/?wc-ajax=checkout")
      .headers(headers_471)
      .formParam("billing_first_name", "Sydney")
      .formParam("billing_last_name", "Adams")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "370M")
      .formParam("billing_email", "Sydney.Adams@testingwizards.com")
      .formParam("order_comments", "no need to fulfill")
      .formParam("woocommerce-process-checkout-nonce", "8ed26c0094")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .exec(http("Userorder1461")
      .get("/checkout/order-received/114411/?key=wc_order_aaLJASQdJn8Dh")
      .headers(headers_472))


  val chain_16 = exec(http("Userorder1558")


      .get("/my-account/orders/")
      .headers(headers_57))


  val chain_17 = exec(http("Userorder1655")


    .post("/my-account/")
    .headers(headers_56)
    .formParam("username", "aguilae  ")
    .formParam("password", "QNfD2UVMLuCQUZf^DreDjR&Z")
    .formParam("woocommerce-login-nonce", "1727039b37")
    .formParam("_wp_http_referer", "/my-account/")
    .formParam("login", "Log in")
    .check(status.in(200,302)))

    .exec(http("Userorder1738")
      .get("/my-account/orders/")
      .headers(headers_57))





  val chain_20 = pause(394 milliseconds)
    .exec(http("Userorder1950")
      .get(uri4 + "?SAMLRequest=jZLLbtswEEX3%2FQqCe%2Brlh2QicuDGCGogbY3Y6aKbgiJHDgFqqJJU3OTrS8s1kAJNUO54eQc8d2aurn91hjyB89piTfMkowRQWqXxUNOH%2FS2r6PXyyovO9Hw1hEe8h58D%2BEBiHXo%2BPtR0cMit8NpzFB14HiTfrT7f8SLJeO9ssNIaei553yy8BxciCyWbdU1%2FtCCaps1LVUk5z%2BayyQooStlKyBo1g9m0qprFFJScUPLtkqI4pdh4P8AGfRAYopTlC5ZnrJjui5znMz4rv1Oy%2FYP2UeM58Htozdnk%2Baf9fsu2X3d7SlYX3BuLfujA7cA9aQkP93c1fQyh9zxNpe16gc8%2BWAfJUb8Ip3wSxZSSdeykRhFG7Ivf2IPGpNPSWW%2FbYNFohLGgzHJQagJMlqJi07JasCaXwCpRTCfzIlPzqk1PIynoeWZ87IJ7Naz%2Fbf%2Fy3%2FQ2SBaVziKLc1VJ0KITgVmnT8zS2EGlxz5aMACGtDdD1H3aadTWCTwAO0GwImM%2B9tLEqz4gs5hepa94Lwv3JQJu1ltrtHwmK2Ps8caBCFDT4Aag5Na6%2BPvbkfIkHxWtWDta%2BYC%2BB6lbDYp%2BIG%2BcdHmm%2BXvjl78B&RelayState=%2Fwp-content%2Fuploads%2F2019%2F08%2Fserra1.jpg&SigAlg=http%3A%2F%2Fwww.w3.org%2F2001%2F04%2Fxmldsig-more%23rsa-sha256&Signature=Pz7r%2FFRCeP49J2Agtru51oOKpPf43V9kC%2FWkGWd1WlZCB4RUGdvgM9QLa3JeEt3T5enZXRi%2FBxCoK6dFVC1XYQkZU8%2BMxU0kcB7MtYtoo7oo3WOcAM4bQnHwppGGmIfjm5y9QqcGv0hJZDox9FQQv%2BJUP2cQA%2Bs8itw%2FmSTpUX%2F%2BGmqy%2FmEFOK%2BkIgn3H1lWzyrgXsDfgDavzrYMw2kGoBEZ6B%2B9GnPRLAcM75D%2FT7Re0pI0QD0i1Dnyo43zVRa0R2KR6xH38BBAonZKdGu%2F9elE7164HY%2Fpk%2B%2BwMhs1IrBrm3wwCERwtI8EsHAy6maz2xKZqUfkSbzoONP7FNz9Tw%3D%3D")
      .headers(headers_163))
    .pause(1)
    .exec(http("Userorder1951")
      .get("/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/")
      .headers(headers_0))


  val chain_21 = exec(http("Userorder2046")


    .post("/?wc-ajax=update_order_review")
    .headers(headers_470)
    .formParam("security", "9120e7aee6")
    .formParam("country", "US")
    .formParam("address", "TEXAS WHSE WOTC")
    .formParam("s_country", "US")
    .formParam("s_address", "TEXAS WHSE WOTC")
    .formParam("has_full_address", "true")
    .formParam("post_data", "billing_first_name=Edwin&billing_last_name=Aguilar&billing_country=US&billing_address_1=TEXAS+WHSE+WOTC&billing_email=edwin.aguilar%40wizards.com&order_comments=&woocommerce-process-checkout-nonce=8f853080be&_wp_http_referer=%2Fcheckout%2F"))
    .pause(10)
    .exec(http("Userorder2140")
      .post("/?wc-ajax=checkout")
      .headers(headers_471)
      .formParam("billing_first_name", "Edwin")
      .formParam("billing_last_name", "Aguilar")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "TEXAS WHSE WOTC")
      .formParam("billing_email", "edwin.aguilar@testingwizards.com")
      .formParam("order_comments", "No need to fulfill")
      .formParam("woocommerce-process-checkout-nonce", "8f853080be")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .exec(http("Userorder2141")
      .get("/checkout/order-received/114413/?key=wc_order_myQbmtLz5D7PQ")
      .headers(headers_472))




  val chain_231 = exec(http("Userorder2241")

    .post("/my-account/")
    .headers(headers_56)
    .formParam("username", "algerc")
    .formParam("password", "M1fe52nTQKK7BrDw@7wjUvMR")
    .formParam("woocommerce-login-nonce", "1727039b37")
    .formParam("_wp_http_referer", "/my-account/")
    .formParam("login", "Log in")
    .check(status.in(200,302)))




  val chain_25 = exec(http("Userorder2436")

    .get(uri4 + "?SAMLRequest=jZLBbtswEETv%2FQqBd0oiZVsSETlwYwQ1kLZG7PTQS0FRK4eAtFRJKm7y9aXlGkiBJihvHM6Cb3b36vpX30VPYJ02WBEWpyQCVKbReKjIw%2F6WFuR6eeVk3w1iNfpHvIefIzgfhTp0YnqoyGhRGOm0Eyh7cMIrsVt9vhM8TsVgjTfKdORc8r5ZOgfWBxYSbdYV%2BaFKJsu8YFzBbF7LdMbLeb2AjElW87qcN3mTta3KFCfRt0sKfkqxcW6EDTov0QcpZSVlKeWzPWeC5SJLv5No%2Bwfto8Zz4PfQ6rPJiU%2F7%2FZZuv%2B72JFpdcG8MurEHuwP7pBU83N9V5NH7wYkkUaYfJD47byzER%2F0ibePiICYkWodOapR%2Bwr74O3PQGPdaWeNM6w12GmEqyFMGTZMBVbks6CwvSlozBbSQfJYteNosijY5jYST88zE1AX7alj%2F2%2F7lv%2BmNVzQovUEa5trEXsteemqsPjGrzoxNchyCBT2gT4ZuDLpLeo3aWIkHoCcIylPqQi%2B7cNUHpAaTq%2BQV72XhvgTAzXprOq2eo1XXmeONBemhIt6OQKJbY8Pvb0diMZsU3dB2sooR3QBKtxoa8iF64yTLM83fG7%2F8DQ%3D%3D&RelayState=%2Fwp-content%2Fuploads%2F2019%2F08%2Fserra1.jpg&SigAlg=http%3A%2F%2Fwww.w3.org%2F2001%2F04%2Fxmldsig-more%23rsa-sha256&Signature=bD77n8D9MqyFUiXEyUSY%2BkpRUKP8rbLXyKJLurI2Kzh8Ie8FgFVGdJqgEhHbZUpx%2F0hKNrcB22XPjupk47R4C9tpdcyBXMsdZZCQ%2BIRWzeRGbepyPepyWW%2FXlnl5iIitrnYtKfMdFuMmO132ta1TYzwzk%2B5sJVcQ0xqdKLeyPGWZYD7Wv2bRR9p1o5JSvcouD0S3DvK9qxoQq7cI9DTqWmac6DUruR1GADuhTztpgxxD%2BY%2FF1igb3JG%2F6JGu%2F1E7faMqjqEBkK843yeOmZLfqkQHqSL8K1%2FDRDZ8BYLS9btXiaX46Df0%2BT1%2F8xT2l3sY6UNYoviIeKGnhp8wV%2BlRpg%3D%3D")
    .headers(headers_163))
    .pause(1)
    .exec(http("Userorder2472")
      .get("/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/")
      .headers(headers_0))


  val chain_26 = exec(http("Userorder2534")


      .post("/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/")
      .headers(headers_2536)
      .body(RawFileBody("companystoretestNoMfa24Oct2019_2536_request.txt")))

    .exec(http("Userorder2601")
      .get("/checkout/")
      .headers(headers_228))


  val chain_27 = exec(http("Userorder2630")

    .get("/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.js?ver=3.6.5")
    .headers(headers_424))

    .exec(http("Userorder2660")
      .post("/?wc-ajax=update_order_review")
      .headers(headers_470)
      .formParam("security", "c44aab3168")
      .formParam("country", "US")
      .formParam("address", "WOTC 221D")
      .formParam("s_country", "US")
      .formParam("s_address", "WOTC 221D")
      .formParam("has_full_address", "true")
      .formParam("post_data", "billing_first_name=CJ&billing_last_name=Alger&billing_country=US&billing_address_1=WOTC+221D&billing_email=cj.alger%40wizards.com&order_comments=&woocommerce-process-checkout-nonce=5f13da3711&_wp_http_referer=%2Fcheckout%2F"))
    .pause(9)
    .exec(http("Userorder2661")
      .post("/?wc-ajax=checkout")
      .headers(headers_471)
      .formParam("billing_first_name", "CJ")
      .formParam("billing_last_name", "Alger")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "WOTC 221D")
      .formParam("billing_email", "cj.alger@testingwizards.com")
      .formParam("order_comments", "No need to fullfill")
      .formParam("woocommerce-process-checkout-nonce", "5f13da3711")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .exec(http("Userorder2662")
      .get("/checkout/order-received/114415/?key=wc_order_dT5Kw7bgVMc1b")
      .headers(headers_472))


  val chain_0112 = exec(http("Userorder0112")
    .get("/")
    .headers(headers_011))


  val chain_55 = exec(http("Userorder98")


    .post("/product/mtg-throne-of-eldraine-the-wildered-quest-e-book-epub-version/")
    .headers(headers_1181)
    .body(RawFileBody("companystoretestNoMfa28Oct2019_0118_request.txt")))

    .exec(http("Userorder183")
      .get("/checkout/")
      .headers(headers_1831))


  val chain_171 = exec(http("Userorder194")


    .post("/?wc-ajax=update_order_review")
    .headers(headers_2421)
    .formParam("security", "53c485cde0")
    .formParam("country", "US")
    .formParam("address", "WOTC Renton: 204B")
    .formParam("s_country", "US")
    .formParam("s_address", "WOTC Renton: 204B")
    .formParam("has_full_address", "true")
    .formParam("post_data", "billing_first_name=Benjamin&billing_last_name=Baker&billing_country=US&billing_address_1=WOTC+Renton%3A+204B&billing_email=benjamin.baker%40wizards.com&order_comments=&woocommerce-process-checkout-nonce=f8ef9ed5cf&_wp_http_referer=%2Fcheckout%2F"))
    .pause(19)
    .exec(http("Userorder243")
      .post("/?wc-ajax=checkout")
      .headers(headers_2431)
      .formParam("billing_first_name", "Benjamin")
      .formParam("billing_last_name", "Baker")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "WOTC Renton: 204B")
      .formParam("billing_email", "benjamin.baker@testingwizards.com")
      .formParam("order_comments", "Only for perf testing")
      .formParam("woocommerce-process-checkout-nonce", "f8ef9ed5cf")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .exec(http("Userorder244")
      .get("/checkout/order-received/114606/?key=wc_order_UaeIAA09oNe59")
      .headers(headers_2441))

  val chain_111 = exec(http("Userorder98")


    .post("/?wc-ajax=update_order_review")
    .headers(headers_188)
    .formParam("security", "dc9a4e79e8")
    .formParam("payment_method", "reward_gateway")
    .formParam("country", "US")
    .formParam("address", "207E")
    .formParam("s_country", "US")
    .formParam("s_address", "207E")
    .formParam("has_full_address", "true")
    .formParam("post_data", "billing_first_name=Ben&billing_last_name=Arnette&billing_country=US&billing_address_1=207E&billing_email=Ben.Arnette%40wizards.com&order_comments=&payment_method=reward_gateway&woocommerce-process-checkout-nonce=6a06576d19&_wp_http_referer=%2Fcheckout%2F"))
    .pause(8)
    .exec(http("Userorder189")
      .post("/?wc-ajax=checkout")
      .headers(headers_189)
      .formParam("billing_first_name", "Ben")
      .formParam("billing_last_name", "Arnette")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "207E")
      .formParam("billing_email", "Ben.Arnette@testingwizards.com")
      .formParam("order_comments", "Perf Testing")
      .formParam("payment_method", "reward_gateway")
      .formParam("woocommerce-process-checkout-nonce", "6a06576d19")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .exec(http("Userorder190")
      .get("/checkout/order-received/114610/?key=wc_order_Q1bbH1tnMfjZq")
      .headers(headers_190))


  val chain_23 = exec(http("Userorder193")

    .get("/")
    .headers(headers_249))


  val chain_32 = exec(http("Userorder291")

    .get(uri4 + "?SAMLRequest=jZJPbxshEMXv%2FRSIO%2FvPG3sXeR25saJaSlsrdnropcIwdpDYYQts3OTTF%2B%2FWUio1UbnxeCN%2Bb2bm179aQ57AeW2xoXmSUQIordJ4bOjD7pZV9Hox96I1HV%2F24RHv4WcPPpBYh54PDw3tHXIrvPYcRQueB8m3y893vEgy3jkbrLSGjiXvm4X34EJkoWS9auiPUpUTkNOymuW1mKg6K65ASlEKIbJSimxW78WhLFQhKfl2SVGcU6y972GNPggMUcrymuUZK6pdXvNyyq%2Bq75Rs%2FqB91DgGfg9tP5o8%2F7Tbbdjm63ZHyfKCe2PR9y24LbgnLeHh%2Fq6hjyF0nqeptG0n8NkH6yA56RfhlE%2BimFKyip3UKMKAffEbe9SYtFo66%2B0hWDQaYSiYZTkoNQEmZ6Ji5ayq2T6XwCpRlJNpkalpdUjPIynoODM%2BdMG9Gtb%2Ftn%2Fxb3obJItKa5HFuaokaNGKwKzTZ2ZpbK%2FSUxctGABD2pk%2B6j5tNWrrBB6BnSFYkTEfe2niVR%2BRWUzn6Svey8J9iYDr1cYaLZ%2FJ0hh7unEgAjQ0uB4oubUu%2Fv52pDzJB0UrdhisvEffgdQHDYp%2BIG%2BcdDHS%2FL3xi98%3D&RelayState=%2Fwp-content%2Fuploads%2F2019%2F08%2Fserra1.jpg&SigAlg=http%3A%2F%2Fwww.w3.org%2F2001%2F04%2Fxmldsig-more%23rsa-sha256&Signature=Dx5OsRdGsHN9oWgt%2Fuv3KMEhxWY7vU6MG8rkA4AoWNcYJ3cvsMVYvkuwKjg3Y7egDOF8ADKviybM0KrI1ahTL0HeoH7%2B%2F1DFETpJ%2FSnwU7M6yWPluJxMkPeRLZSexuo%2FOctqpbCZT9a6LfmboKfmFZMv09CBQF2CUAxEkDTnInQ4eWG0gOK9mSVdCaPU6aqilUyrtFwFqxk94rDRfG%2Fi3L6R1dziC4Os%2FbJpm4HzRLJt6gC%2B9cioqN4wSte%2FTFM64OgxpvjKDcmi2r2gc7KoEjK40fIcdK0LddfoacprvRZ%2BZoeSg%2BS46PFgIgonM%2BWl7q7IMLbVF8cbcOFiK5bWrg%3D%3D")
    .headers(headers_302))
    .pause(4)
    .exec(http("Userorder303")
      .get("/product/mtg-throne-of-eldraine-deluxe-collection/")
      .headers(headers_0))

    .exec(http("Userorder366")
      .get(uri1 + "")
      .headers(headers_322))
    .pause(4)
    .exec(http("Userorder367")
      .post("/product/mtg-throne-of-eldraine-deluxe-collection/")
      .headers(headers_367)
      .body(RawFileBody("companystoretestArnettB28Oct2019_0367_request.txt")))


  val chain_41 = exec(http("Userorder387")

    .post("/product/mtg-throne-of-eldraine-deluxe-collection/")
    .headers(headers_432)
    .body(RawFileBody("companystoretestArnettB28Oct2019_0432_request.txt")))
    .pause(120 milliseconds)

  val chain_5 = exec(http("Userorder484")


    .get("/checkout/")
    .headers(headers_496))

    .exec(http("Userorder555")
      .post("/?wc-ajax=update_order_review")
      .headers(headers_188)
      .formParam("security", "dc9a4e79e8")
      .formParam("payment_method", "reward_gateway")
      .formParam("country", "US")
      .formParam("address", "207E")
      .formParam("s_country", "US")
      .formParam("s_address", "207E")
      .formParam("has_full_address", "true")
      .formParam("post_data", "billing_first_name=Ben&billing_last_name=Arnette&billing_country=US&billing_address_1=207E&billing_email=Ben.Arnette%40wizards.com&order_comments=&payment_method=reward_gateway&woocommerce-process-checkout-nonce=6a06576d19&_wp_http_referer=%2Fcheckout%2F"))
    .pause(8)
    .exec(http("Userorder556")
      .post("/?wc-ajax=checkout")
      .headers(headers_189)
      .formParam("billing_first_name", "Ben")
      .formParam("billing_last_name", "Arnette")
      .formParam("billing_country", "US")
      .formParam("billing_address_1", "207E")
      .formParam("billing_email", "Ben.Arnette@testingwizards.com")
      .formParam("order_comments", "Only For Perf Tests")
      .formParam("payment_method", "reward_gateway")
      .formParam("woocommerce-process-checkout-nonce", "6a06576d19")
      .formParam("_wp_http_referer", "/?wc-ajax=update_order_review"))
    .exec(http("Userorder557")
      .get("/checkout/order-received/114612/?key=wc_order_cWkYHqRQmQtoE")
      .headers(headers_190))


  val chain_22 = exec(http("Userorder292")
    .get("/wp-content/plugins/rewardsystem/assets/js/checkoutscript.js?ver=5.2.4")
    .headers(headers_24512))


  val scn = scenario("companystoretestNoMfa24Oct2019").exec(
    chain_0, chain_111,chain_231,chain_1, chain_55,chain_2,chain_23, chain_3,chain_32, chain_41,chain_4,chain_5,  chain_6, chain_7,chain_0112, chain_8, chain_9, chain_10, chain_11, chain_13, chain_14,chain_22, chain_15, chain_16, chain_171, chain_20, chain_21,chain_23, chain_25, chain_26, chain_27)

  //setUp(scn.inject(atOnceUsers(100))).protocols(httpProtocol)


  setUp(
    scn.inject(
      nothingFor(2 seconds),
      //atOnceUsers(99099),
     // rampUsers(400) over (200 seconds)
      constantUsersPerSec(100) during (100 seconds)
      //rampUsers(1) during  (20 second)
    ).protocols(httpProtocol))
    .maxDuration(200 seconds)





}


