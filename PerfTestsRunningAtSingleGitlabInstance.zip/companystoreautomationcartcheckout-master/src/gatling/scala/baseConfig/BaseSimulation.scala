package baseConfig

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.core.filter.{ BlackList, Filters, WhiteList }

class BaseSimulation extends Simulation {

val httpConf = http
    // Here is the root for all relative URLs
    .baseURL("https://prod.magic.tiamat-origin.cloud")
    .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
    .acceptEncodingHeader("gzip, deflate")
    .acceptLanguageHeader("en-US,en;q=0.5")
    .userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:16.0) Gecko/20100101 Firefox/16.0")
    // More generic methods are available too

val httpProtocol = http
   .baseURL("https://companystoretest.wizards.com")
   .disableFollowRedirect
   .disableAutoReferer
   .userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36")

}
